import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class DataValidator {

	public static boolean Stringstarts(String name) throws PLPException{
		
		if(Pattern.matches("[gG]{1}[a-zA-Z]{2,}",name)){
			return true;
		}
		else{
			throw new PLPException("String should start with g");
		}
		
	}
	public static boolean Stringends(String name) throws PLPException{
		
			if(name.endsWith("g")){
				return true;
		}
		else{
			throw new PLPException("String should end with g");
		}
		
	}
	public static boolean Validatequals(String pass,String cnfrm) throws PLPException{
		if(pass.equals(cnfrm)){
		return true;
		}
		else{
			throw new PLPException("The two strings does not match");
		}
	
	}
	public static boolean ValidatePhone(String phoneno) throws PLPException{
		if(phoneno.length()==10){
		return true;
		}
		else{
			throw new PLPException("Phone number format does not match");
		}
	}
	
	 public static boolean Validatemail(String email) throws PLPException
	    {
		 Pattern emailNamePtrn = Pattern.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		 Matcher mtch = emailNamePtrn.matcher(email);

		 if(mtch.matches()){
	            return true;
	        }
	        else
	        {
	        	throw new PLPException("Enter a valid email");
	        }
	    }
	 public static boolean Validatealpha(String name) throws PLPException{
			
			Pattern p = Pattern.compile("[a-zA-Z0-9]{1,}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
		else{
			throw new PLPException("String should contain only alpha numeric characters");
		}
		
	}
	 public static boolean ValidateNumbers(String name) throws PLPException{
			
			Pattern p = Pattern.compile("[0-9]{1,}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
		else{
			throw new PLPException("String contains characters other than  numeric characters");
		}
		
	}
	 public static boolean ValidateUppercase(String name) throws PLPException{
			
		 int length = name.length();
		 int i;
		 for(i = 0; i < length; i++) {
			 char character = name.charAt(i);
			 if(Character.isUpperCase(character)) {
		         return true;
		    }			 
		 }
		 if(i==length)
		 {
			 throw new PLPException("String does not contain any Upper Case letter");	 
		 }
		return false;
	
	}
	 public static boolean ValidatePass(String name) throws PLPException{
			
			Pattern p = Pattern.compile("[a-zA-Z0-9]{4,15}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
		else{
			throw new PLPException("Password should contain oonly alphanumeric charcters and string length should be between 4 to 10");
		}
		
	}
	 public static boolean ValidateName(String name) throws PLPException{
			
			Pattern p = Pattern.compile("[a-zA-Z]{2,15}");//. represents single character  
			Matcher m = p.matcher(name);    
			if(m.matches()){
				return true;
		}
		else{
			throw new PLPException("Name should contain only uppercase and lower case characters");
		}
		
	}
}

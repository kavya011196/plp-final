import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class plplogin {
	public static void main(String[] args) throws InterruptedException, PLPException {
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		driver.get("http://demo.opencart.com");
		Thread.sleep(1000);
		
        System.out.println("Execution is stopped for 10 seconds");
		boolean title=driver.getTitle().contains("Your Store");
		if(title)
		{
			System.out.println("Title matches");
		}
		else
		{
			System.out.println("Title not matches");
		}
		
		driver.findElement(By.linkText("My Account")).click();
		Thread.sleep(1000);
		System.out.println("My Account is clicked");
		
		driver.findElement(By.linkText("Login")).click();
		//Thread.sleep(1000);
		System.out.println("Login is clicked");
	
	driver.findElement(By.name("email")).sendKeys("techcookies@gmail.com");
	WebElement mail = driver.findElement(By.name("email"));
	String email = mail.getAttribute("value");
	if(DataValidator.Validatemail(email))//Validating first name
	{
		System.out.println("Email verified");
	    Thread.sleep(1000);
	    driver.findElement(By.name("password")).sendKeys("techcookies");
	    Thread.sleep(1000);
	    WebElement pass = driver.findElement(By.name("password"));
		String pwrd = pass.getAttribute("value");
		if(DataValidator.ValidatePass(pwrd))
		{
			driver.findElement(By.xpath("//input[@value='Login']")).click();
			System.out.println("login  successfully");
	        driver.findElement(By.linkText("Edit your account information")).click();
	        Thread.sleep(1000);
	        System.out.println("Edit your account information is clicked");
	        driver.findElement(By.xpath(".//*[@id='content']/form/div/div[2]/input")).click();
	        driver.findElement(By.linkText("Modify your address book entries")).click();
	        Thread.sleep(1000);
	        driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/a")).click();
	        driver.findElement(By.name("firstname")).sendKeys("tech");
	        WebElement name = driver.findElement(By.xpath(".//*[@id='input-firstname']"));
			String fname = name.getAttribute("value");
			if(DataValidator.ValidateName(fname))
			{
				System.out.println("First Name verified");
				driver.findElement(By.name("lastname")).sendKeys("cookies");
				WebElement Lname = driver.findElement(By.name("lastname"));
				String lname = Lname.getAttribute("value");
				if(DataValidator.ValidateName(lname))
				{
					System.out.println("Last Name verified");
					driver.findElement(By.name("company")).sendKeys("capgemini");
					WebElement Comp = driver.findElement(By.name("lastname"));
					String comp = Comp.getAttribute("value");
					if(DataValidator.ValidateName(comp))
					{
						System.out.println("Company name verified");
						driver.findElement(By.name("address_1")).sendKeys("27uhedsajnfclnhss");
						WebElement Addr= driver.findElement(By.name("address_1"));
						String addr = Addr.getAttribute("value");
						Thread.sleep(1000);
						if(DataValidator.Validatealpha(addr))
						{
							System.out.println("Address verified");
							driver.findElement(By.name("city")).sendKeys("chennai");
							WebElement City = driver.findElement(By.name("city"));
							String city = City.getAttribute("value");
							if(DataValidator.ValidateName(city))
							{
								System.out.println("City name verified");
								driver.findElement(By.name("postcode")).sendKeys("123456");
								Select fromCountry= new Select(driver.findElement(By.id("input-country")));
								fromCountry.selectByIndex(106);
								WebElement Country = fromCountry.getFirstSelectedOption();
								String country = Country.getText();
								if(country.equals("India"))
									System.out.println("India is selected");
								else
									System.out.println("Other country is selected");
								Thread.sleep(1500);
								Select fromState= new Select(driver.findElement(By.id("input-zone")));
								fromState.selectByVisibleText("Bihar");
								Thread.sleep(1500);
								WebElement State = fromState.getFirstSelectedOption();
								String state = State.getText();
								if(state.equals("Bihar"))
									System.out.println("Bihar state selected");
								else
									System.out.println("Other state selected");
								System.out.println("Closing the browser");
								Thread.sleep(3000);
								driver.quit();
							}
						}
					}
				}
			}
		}
	}
	}
}
	




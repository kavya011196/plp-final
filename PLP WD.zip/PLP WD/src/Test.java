
public class Test {

	public static void main(String[] args) throws PLPException {
		// TODO Auto-generated method stub
		String name="gang";
     if(DataValidator.Stringstarts(name))
     {
    	 System.out.println("Verified");
     } 
     if(DataValidator.Stringends(name))
     {
    	 System.out.println("Verified");
     } 
     String a="Simham",b="Simham";
     if(DataValidator.Validatequals(a, b))
     {
    	 System.out.println("Verified");
     }
     String testa="1asd4";
     if(DataValidator.Validatealpha(testa))
     {
    	 System.out.println("Verified");
     }
     String no="123";
     if(DataValidator.ValidateNumbers(no))
     {
    	 System.out.println("Verified");
     }
     String name1="ganesH";
     if(DataValidator.ValidateUppercase(name1))
     {
    	 System.out.println("Verified");
     }
     
	}

}
